export default {
  LIGHT: '200',
  LIGHTER: '300',
  REGULAR: '400',
  BOLDER: '500',
  MEDIUM: '600',
  BOLD: '700',
  HEAVY: '800',

  BIG: '30',

  NAME: 'Roboto',
}
