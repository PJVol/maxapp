export { default as Pinpad } from "./Pinpad";
