export { default as IptvInfo } from "./IptvInfo";
