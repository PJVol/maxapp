export { default as AutoPayment } from "./AutoPayment";
