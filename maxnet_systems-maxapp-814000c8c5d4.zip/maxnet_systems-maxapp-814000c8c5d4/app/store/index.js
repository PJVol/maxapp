export * from "./status/actions";
export * from "./auth/actions";
export * from "./agreement/actions";
export * from "./services/actions";
export * from "./payments/actions";

import store from "./store";
export default store;
