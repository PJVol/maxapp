import { StyleSheet } from 'react-native'
import { Colors } from '../../config'

export default StyleSheet.create({
  logout: {
    color: Colors.WHITE_TEXT,
    fontSize: 22,
    marginLeft: 5,
  },
})
